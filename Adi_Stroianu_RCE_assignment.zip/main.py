import sys
import os
import socket
import time
import threading
import requests
import json
from socket_utils import receive_message, send_message
import slave
import importlib

SLAVE_FILE_NAME = "slave.py"

def check_slave():
    """
    Check if the slave can run without crashes by calling its internal functions.
    """
    try:
        slave.heartbeat()  # Call a heartbeat function in slave if it exists
        return True
    except Exception as e:
        print(f"Slave check failed: {e}")
        return False

def update_slave(params):
    """
    Update the slave file by downloading it from the provided URL.
    Backup the old file before updating and restore if the update fails.
    """
    update_url = params.get("url")
    if not update_url:
        print("Invalid update URL")
        return json.dumps({"success": False, "message": "Invalid update URL"})
    backup_file = SLAVE_FILE_NAME + ".bak"
    if os.path.exists(backup_file):
        os.remove(backup_file)
    os.rename(SLAVE_FILE_NAME, backup_file)

    try:
        # Download the updated slave file
        response = requests.get(update_url)
        if response.status_code == 200:
            with open(SLAVE_FILE_NAME, "w") as file:
                file.write(response.text)
        else:
            print("Failed to download update")
            raise Exception("Failed to download update")

        # Re-import the updated slave module
        importlib.reload(slave)
        # Check if the updated slave can run without crashes
        if check_slave():
            return json.dumps({"success": True, "message": "Slave updated successfully"})
        else:
            print("Updated slave check failed")
            # Throw an exception to restore the backup file
            raise Exception("Updated slave check failed")
    except Exception as e:
        # Restore the backup file if update fails
        print(f"Update failed: {e}")
        os.rename(backup_file, SLAVE_FILE_NAME)
        return json.dumps({"success": False, "message": f"Update failed: {e}"})

def perform_action(action):
    """
    Perform the specified action by calling functions from the slave module.
    """
    action_name = action.get("action")
    params = action.get("params", {})

    if action_name in slave.ACTIONS:
        result = slave.ACTIONS[action_name](params)
        return json.dumps(result)
    else:
        return json.dumps({"success": False, "message": "Invalid action"})

def get_slave_actions(_):
    """
    Get the list of actions available in the slave module.
    """
    importlib.reload(slave)
    return json.dumps({"success": True, "message": list(slave.ACTIONS.keys())})

ACTIONS = {
    "update_slave": update_slave,
    "check_slave": check_slave,
    "get_actions": get_slave_actions
}

def handle_client(client, address):
    """
    Handle incoming client connections, receive actions, and respond with results.
    """
    try:
        while True:
            importlib.reload(slave)
            action = receive_message(client)
            if not action:  # Exit loop if no data is received (client disconnected)
                break

            action = json.loads(action)
            if action.get("action") in ACTIONS:
                print(f"Performing action {action['action']}")
                result = ACTIONS[action["action"]](action.get("params"))
            else:
                print("Invalid action, performing through slave")
                result = perform_action(action)

            send_message(client, result)
    except Exception as e:
        print(f"Client connection error: {e}")
    finally:
        client.close()

def main():
    """
    Start the socket server to handle client requests.
    """
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("0.0.0.0", 12345))
    server.listen(5)
    print("Server started")
    while True:
        importlib.reload(slave)
        client, address = server.accept()
        threading.Thread(target=handle_client, args=(client, address)).start()

if __name__ == "__main__":
    main()